#ifndef __PARSE_H__
#define __PARSE_H__

void parse(char *buf);

#endif //__PARSE_H__

