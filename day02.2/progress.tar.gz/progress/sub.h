#ifndef __SUB_H__
#define __SUB_H__

int sub(int a, int b);

#endif //__SUB_H__

