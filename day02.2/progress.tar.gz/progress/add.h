#ifndef __ADD_H__
#define __ADD_H__

int add(int a, int b);

#endif //__ADD_H__

