
#ifndef __MUL_H__
#define __MUL_H__

int mul(int a, int b);

#endif //__MUL_H__

